from django.apps import AppConfig


class App02Config(AppConfig):
    name = 'app02'
